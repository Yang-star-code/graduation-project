% uncomment the next two lines to use the MATLAB desktop
%desktop;
%keyboard;

% control step
TIME_STEP = 32;

% get and enable camera
camera3 = wb_robot_get_device('camera_for_sur3');
wb_camera_enable(camera3,TIME_STEP);
wb_camera_recognition_enable(camera3, TIME_STEP)

% get the motors and set target position to infinity (position control)
base_motor3 = wb_robot_get_device('base_motor3');%%0~1.57
end_motor3 = wb_robot_get_device('end_motor3');%3.14~1.57
wb_motor_set_position(base_motor3, 0);
wb_motor_set_position(end_motor3, 3.14);


wb_motor_set_position(base_motor3, 0.785);
wb_motor_set_position(end_motor3, 2.355);

wb_console_print('Hello!', WB_STDOUT);
wb_console_print(strcat('Running', ANSI_RED_FOREGROUND, ' Matlab', ANSI_RESET, ' sample Webots controller.'), WB_STDOUT);

width = wb_camera_get_width(camera3);
height = wb_camera_get_height(camera3);
fov=1.2;

goal=zeros(1,3);
time=0;
while wb_robot_step(TIME_STEP) ~= -1
  time=time+1;
  rgb3 = wb_camera_get_image(camera3);
  
  % Process sensor data here
  number = wb_camera_recognition_get_number_of_objects(camera3);
  wb_console_print(['id: ', num2str(number)],WB_STDOUT);

  %select the goal
  if number>0
      ob= wb_camera_recognition_get_objects(camera3);
      wb_console_print('OK', WB_STDOUT);
      for i=1:number
         if ob(i).size_on_image(1)*ob(i).size_on_image(2)>goal(3)
             goal(1)=ob(i).position_on_image(1);
             goal(2)=ob(i).position_on_image(2);
             goal(3)=ob(i).size_on_image(1)*ob(i).size_on_image(2);
         end    
      end
     %perform tracking
      dx = goal(1)- width / 2;
      dy = goal(2) - height / 2;
      % send actuator commands
      wb_motor_set_position(base_motor3, inf);
      wb_motor_set_velocity(base_motor3,-1.5 * dx / width);
      wb_motor_set_position(end_motor3, inf);
      wb_motor_set_velocity(end_motor3 ,-1.5 * dy / height);
      density(time)=1*400*300-0.8*goal(3);
      world_time(time)=time;   
      goal=zeros(1,3);
      wb_camera_set_fov(camera3, fov);
      if time>1
       if density(time)>density(time-1)&fov>0.3
       fov=fov-0.01;
       end
      end
  else
      wb_motor_set_position(base_motor3, 0.785);
      wb_motor_set_position(end_motor3, 2.355);
      density(time)=1*400*300;
      world_time(time)=time;
  end
  
  % draw the curves
  % subplot(2,2,1);
  plot(world_time(1:time-1),density(2:time));
  title('Camera3 Cost Function');
  xlabel('iterations');
  drawnow;

end
