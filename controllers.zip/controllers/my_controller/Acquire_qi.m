function [x,y]=Acquire_qi(qimx,qimy)

end