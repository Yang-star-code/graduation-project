% uncomment the next two lines to use the MATLAB desktop
% desktop;
% keyboard;

% control step
TIME_STEP = 32;

% get and enable camera
camera1 = wb_robot_get_device('camera_for_sur1');
wb_camera_enable(camera1,TIME_STEP);
wb_camera_recognition_enable(camera1, TIME_STEP)
wb_camera_recognition_enable_segmentation(camera1);

% get the motors and set target position to infinity (position control)
base_motor1 = wb_robot_get_device('base_motor1');%0~-1.57
end_motor1 = wb_robot_get_device('end_motor1');%3.14~1.57
wb_motor_set_position(base_motor1, 0);
wb_motor_set_position(end_motor1, 3.14);

wb_motor_set_position(base_motor1, -0.785);
wb_motor_set_position(end_motor1, 2.355);

wb_console_print('Hello!', WB_STDOUT);
wb_console_print(strcat('Running', ANSI_RED_FOREGROUND, ' Matlab', ANSI_RESET, ' sample Webots controller.'), WB_STDOUT);

width = wb_camera_get_width(camera1);
height = wb_camera_get_height(camera1);
fov=1.2;

goal=zeros(1,3);
time=0;
while wb_robot_step(TIME_STEP) ~= -1
  time=time+1;
  rgb1 = wb_camera_get_image(camera1);
  
  % Process sensor data here
  number = wb_camera_recognition_get_number_of_objects(camera1);
  wb_console_print(['id: ', num2str(number)],WB_STDOUT);

  %select the goal
  if number>0
      ob= wb_camera_recognition_get_objects(camera1);
      wb_console_print('OK', WB_STDOUT);
      for i=1:number
         if ob(i).size_on_image(1)*ob(i).size_on_image(2)>goal(3)
             goal(1)=ob(i).position_on_image(1);
             goal(2)=ob(i).position_on_image(2);
             goal(3)=ob(i).size_on_image(1)*ob(i).size_on_image(2);
         end    
      end
     %perform tracking
      dx = goal(1)- width / 2;
      dy = goal(2) - height / 2;
      % send actuator commands
      wb_motor_set_position(base_motor1, inf);
      wb_motor_set_velocity(base_motor1,-2 * dx / width);
      wb_motor_set_position(end_motor1, inf);
      wb_motor_set_velocity(end_motor1 ,-2 * dy / height);
      density(time)=1*400*300-0.8*goal(3);
      world_time(time)=time;   
      goal=zeros(1,3);
      wb_camera_set_fov(camera1, fov);
      if time>1
       if density(time)>density(time-1)&fov>0.2
       fov=fov-0.03;
       end
      end
  else
      wb_motor_set_position(base_motor1, -0.785);
      wb_motor_set_velocity(base_motor1,0);
      wb_motor_set_position(end_motor1, 2.355);
      wb_motor_set_velocity(end_motor1 ,0);
      density(time)=1*400*300;
      world_time(time)=time;
  end
  
  % draw the curves
  % subplot(2,2,1);
  plot(world_time(1:time-1),density(2:time));
  title('Camera1 Cost Function');
  xlabel('iterations');
  drawnow;

end
  % flush graphics

  % subplot(2,2,2);
  % image(rgb1);
  % title('Raw Image');

  % gray 
  % subplot(2,2,3);
  % gray1 = im2gray(rgb1);
  % image(gray1);
  % title('Gray Image');
  
  % opticFlow
  % subplot(2,2,4);
  % opticFlow = opticalFlowLK('NoiseThreshold', 0.02);
  % flow = estimateFlow(opticFlow, gray1);
  % 在RGB图像上绘制光流向量图，设置降采样因子和缩放因子
  % plot(flow, 'DecimationFactor', [5 5], 'ScaleFactor', 10);
  % set(gca,'Ydir','reverse'); 
  % title('Optic Flow');
  % uncomment the next line if there's graphics to flush
  % drawnow;
  
  % subplot(1,3,1);
  % image(rgb1);
  % title('Raw Image');
  % axis image;
  
  % subplot(1,3,2);
  % gray1 = im2gray(rgb1);
  % image(gray1);
  % title('Gray Image');
  % axis image;
  
  % subplot(1,3,3);
  % opticFlow = opticalFlowLK('NoiseThreshold', 0.02);
  % flow = estimateFlow(opticFlow, gray1);
  % plot(flow, 'DecimationFactor', [5 5], 'ScaleFactor', 10);
  % set(gca,'Ydir','reverse'); 
  % title('Optic Flow');
  % axis image;
  
  % drawnow;